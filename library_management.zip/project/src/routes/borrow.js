const express = require('express');
const { auth, isLibrarian } = require('../middleware/auth');
const BorrowModel = require('../models/borrow');

const router = express.Router();

router.post('/request', auth, async (req, res) => {
  try {
    const { book_id, start_date, end_date } = req.body;
    const user_id = req.user.id;

    if (!book_id || !start_date || !end_date) {
      return res.status(400).json({ error: 'Book ID, start date, and end date are required' });
    }

    const request = await BorrowModel.createRequest(user_id, book_id, start_date, end_date);
    res.status(201).json(request);
  } catch (error) {
    res.status(500).json({ error: 'Error creating borrow request' });
  }
});

router.get('/requests', auth, isLibrarian, async (req, res) => {
  try {
    const requests = await BorrowModel.getAllRequests();
    res.json(requests);
  } catch (error) {
    res.status(500).json({ error: 'Error fetching borrow requests' });
  }
});

router.put('/request/:id', auth, isLibrarian, async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    if (!['approved', 'denied'].includes(status)) {
      return res.status(400).json({ error: 'Invalid status' });
    }

    const result = await BorrowModel.updateRequestStatus(id, status);

    if (status === 'approved') {
      const request = await BorrowModel.getRequestById(id);
      await BorrowModel.addToHistory(request.user_id, request.book_id);
    }

    res.json(result);
  } catch (error) {
    res.status(500).json({ error: 'Error updating borrow request' });
  }
});

module.exports = router;