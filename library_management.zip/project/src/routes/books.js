const express = require('express');
const { auth, isLibrarian } = require('../middleware/auth');
const BookModel = require('../models/book');

const router = express.Router();

router.get('/', auth, async (req, res) => {
  try {
    const books = await BookModel.getAll();
    res.json(books);
  } catch (error) {
    res.status(500).json({ error: 'Error fetching books' });
  }
});

router.post('/', auth, isLibrarian, async (req, res) => {
  try {
    const { title, author, quantity } = req.body;
    
    if (!title || !author || !quantity) {
      return res.status(400).json({ error: 'Title, author, and quantity are required' });
    }

    const book = await BookModel.create(title, author, quantity);
    res.status(201).json(book);
  } catch (error) {
    res.status(500).json({ error: 'Error adding book' });
  }
});

module.exports = router;