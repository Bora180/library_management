const { db } = require('../config/database');

class BorrowModel {
  static createRequest(userId, bookId, startDate, endDate) {
    return new Promise((resolve, reject) => {
      const stmt = db.prepare(
        'INSERT INTO borrow_requests (user_id, book_id, start_date, end_date) VALUES (?, ?, ?, ?)'
      );
      stmt.run([userId, bookId, startDate, endDate], function(err) {
        if (err) reject(err);
        else resolve({ id: this.lastID, status: 'pending' });
      });
    });
  }

  static getAllRequests() {
    return new Promise((resolve, reject) => {
      db.all(`
        SELECT br.*, u.email, b.title 
        FROM borrow_requests br
        JOIN users u ON br.user_id = u.id
        JOIN books b ON br.book_id = b.id
      `, (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });
  }

  static updateRequestStatus(id, status) {
    return new Promise((resolve, reject) => {
      db.run('UPDATE borrow_requests SET status = ? WHERE id = ?', [status, id], (err) => {
        if (err) reject(err);
        else resolve({ id, status });
      });
    });
  }

  static addToHistory(userId, bookId) {
    return new Promise((resolve, reject) => {
      const stmt = db.prepare(
        'INSERT INTO borrow_history (user_id, book_id, borrowed_on) VALUES (?, ?, ?)'
      );
      stmt.run([userId, bookId, new Date().toISOString()], function(err) {
        if (err) reject(err);
        else resolve({ id: this.lastID });
      });
    });
  }
}

module.exports = BorrowModel;