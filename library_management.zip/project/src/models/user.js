const { db } = require('../config/database');

class UserModel {
  static create(email, hashedPassword, role = 'user') {
    return new Promise((resolve, reject) => {
      const stmt = db.prepare('INSERT INTO users (email, password, role) VALUES (?, ?, ?)');
      stmt.run([email, hashedPassword, role], function(err) {
        if (err) reject(err);
        else resolve({ id: this.lastID, email, role });
      });
    });
  }

  static findByEmail(email) {
    return new Promise((resolve, reject) => {
      db.get('SELECT * FROM users WHERE email = ?', [email], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });
  }
}

module.exports = UserModel;