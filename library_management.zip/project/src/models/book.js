const { db } = require('../config/database');

class BookModel {
  static getAll() {
    return new Promise((resolve, reject) => {
      db.all('SELECT * FROM books', (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });
  }

  static create(title, author, quantity) {
    return new Promise((resolve, reject) => {
      const stmt = db.prepare('INSERT INTO books (title, author, quantity) VALUES (?, ?, ?)');
      stmt.run([title, author, quantity], function(err) {
        if (err) reject(err);
        else resolve({ id: this.lastID, title, author, quantity });
      });
    });
  }
}

module.exports = BookModel;